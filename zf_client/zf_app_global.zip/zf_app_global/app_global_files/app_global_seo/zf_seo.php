<?php

/**
 * This is where you paste all your SEO codes that are necessary for the global
 * view of your application. 
 */
?>

<title><?php echo $zf_applicationStatus['application_title']; ?></title>

<!--Meta tags utilised specifically by Zilas PHP Framework goes in this section-->
<meta name="description" content="Zilas PHP Framework is an open, easy and most secure. First in Africa">
<meta name="keywords" content="Zilas PHP Framework, Zilas PHP, Zilas Framework, PHP Framework, Secure, Open, Easy, African Framework">
<meta name="author" content="Mathew Juma O (Athias Avians)">
<meta charset="UTF-8">

