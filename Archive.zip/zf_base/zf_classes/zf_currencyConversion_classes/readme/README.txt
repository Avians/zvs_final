This is where the cache files are stored. Feel free to delete them at your leisure. Caching will only work if this folder has the correct permissions set.  
  
All cache files are .convertcache. They are in the format of:  
  
Unix Timestamp  
Conversion Rate  