<?php

    echo '<script type="text/javascript" src="'. ZF_ROOT_PATH . ZF_PLUGINS .'zf_fusion_charts'.DS.'fusioncharts_js'.DS.'fusioncharts.js"></script>';
    echo '<script type="text/javascript" src="'. ZF_ROOT_PATH . ZF_PLUGINS .'zf_fusion_charts'.DS.'fusioncharts_js'.DS.'themes'.DS.'fusioncharts.theme.ocean.js"></script>';
    echo '<script type="text/javascript" src="'. ZF_ROOT_PATH . ZF_PLUGINS .'zf_fusion_charts'.DS.'fusioncharts_js'.DS.'themes'.DS.'fusioncharts.theme.carbon.js"></script>';
    echo '<script type="text/javascript" src="'. ZF_ROOT_PATH . ZF_PLUGINS .'zf_fusion_charts'.DS.'fusioncharts_js'.DS.'themes'.DS.'fusioncharts.theme.fint.js"></script>';
    echo '<script type="text/javascript" src="'. ZF_ROOT_PATH . ZF_PLUGINS .'zf_fusion_charts'.DS.'fusioncharts_js'.DS.'themes'.DS.'fusioncharts.theme.zune.js"></script>';
    
?>
