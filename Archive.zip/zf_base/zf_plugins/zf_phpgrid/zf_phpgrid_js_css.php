<?php 

 echo '<link rel="stylesheet" href="'.ZF_ROOT_PATH . ZF_PLUGINS .'zf_phpgrid'.DS.'lib'.DS.'phpgrid_js'.DS.'themes'.DS.'redmond'.DS.'jquery-ui.custom.css" >';  
 echo '<link rel="stylesheet" href="'.ZF_ROOT_PATH . ZF_PLUGINS .'zf_phpgrid'.DS.'lib'.DS.'phpgrid_js'.DS.'jqgrid'.DS.'css'.DS.'ui.jqgrid.css">';

 echo '<link rel="stylesheet" href="'.ZF_ROOT_PATH . ZF_PLUGINS .'zf_phpgrid'.DS.'lib'.DS.'phpgrid_js'.DS.'jqgrid'.DS.'css'.DS.'ui.bootstrap.jqgrid.css">';
 
 //echo '<script type="text/javascript" src=" '.ZF_ROOT_PATH . ZF_PLUGINS . 'zf_phpgrid'.DS.'lib'.DS.'phpgrid_js'.DS.'jquery.min.js"></script>';
 echo '<script type="text/javascript" src=" '.ZF_ROOT_PATH . ZF_PLUGINS . 'zf_phpgrid'.DS.'lib'.DS.'phpgrid_js'.DS.'jqgrid'.DS.'js'.DS.'i18n'.DS.'grid.locale-en.js"></script>';
 echo '<script type="text/javascript" src=" '.ZF_ROOT_PATH . ZF_PLUGINS . 'zf_phpgrid'.DS.'lib'.DS.'phpgrid_js'.DS.'jqgrid'.DS.'js'.DS.'jquery.jqGrid.min.js"></script>';    
 //echo '<script type="text/javascript" src=" '.ZF_ROOT_PATH . ZF_PLUGINS . 'zf_phpgrid'.DS.'lib'.DS.'phpgrid_js'.DS.'themes'.DS.'jquery-ui.custom.min.js"></script>';

 ?>





