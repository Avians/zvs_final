<?php

/**
 * -----------------------------------------------------------------------------
 * THIS IS SYSTEM ERROR 100 FILE. ITS AN ERROR RENDERED WHEN THE DEFAULT
 * CONTROLLER IS INVALID. I.E THE REQUESTED DEFAULT CONTROLLER IS NOT AMONG THE
 * EXECUTABLE CONTROLLER IN YOUR APPLICATION.
 * -----------------------------------------------------------------------------
 *
 * @author Mathew Juma O. (ATHIAS AVIANS) <mathew@headsafrica.com>
 * @time  12th/August/2013  Time: 09:00 EMT
 * @link http://www.zilasframework.com/
 * @copyright Copyright &copy; 2013 Zilas Software LLC
 * @license http://www.zilasframework.com/license/
 * @version 1.01 Final
 * @since version 1.01 Final - 11th/August/2013
 * 
 */

    echo "This is the default construction view for your application<br>";
    echo __FILE__;

?>