<?php

/**
 * This is where you paste all your SEO codes that are necessary for this view
 * pack.
 */
    echo "This the Default Errors SEO file";

?>
