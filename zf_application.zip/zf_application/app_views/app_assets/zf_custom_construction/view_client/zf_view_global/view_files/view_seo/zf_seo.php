<title><?php echo "Custom Construction | ".$zf_applicationStatus['application_title']; ?></title>

<!--Meta tags utilised specifically by Zilas PHP Framework goes in this section-->
<meta name="description" content="Zilas PHP Framework is an open, easy and most secure. First in Africa">
<meta name="keywords" content="Zilas PHP Framework, Zilas PHP, Zilas Framework, PHP Framework, Secure, Open, Easy, African Framework">
<meta name="author" content="Mathew Juma O (Athias Avians)">
<meta charset="UTF-8">
