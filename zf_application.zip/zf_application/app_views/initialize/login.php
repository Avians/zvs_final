<?php

 //The login form is held in this widget file.
 $zf_widgetFolder = "initialize"; $zf_widgetFile = "login_form.php";
 Zf_ApplicationWidgets::zf_load_widget($zf_widgetFolder, $zf_widgetFile);
 
?>