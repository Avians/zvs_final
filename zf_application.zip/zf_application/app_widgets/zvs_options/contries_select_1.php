<option value=""></option>

<!--This is an option listing of all world's countries with there Initials, Call Codes and Currencies as values.-->
<!--Countries Starting with A-->
<option value="AF:+93:AFN">Afghanistan</option>
<option value="AL:+355:ALL">Albania</option>
<option value="DZ:+213:DZD">Algeria</option>
<option value="AS:+1 684:USD">American Samoa</option>
<option value="AD:+376:ADP">Andorra</option>
<option value="AO:+244:AOA">Angola</option>
<option value="AG:+1 268:XCD">Antigua and Barbuda</option>
<option value="AI:+1 264:XCD">Anguilla</option>
<!--<option value="AQ:0:AQD">Antarctica</option>-->
<option value="AR:+54:ARS">Argentina</option>
<option value="AM:+374:AMD">Armenia</option>
<option value="AW:+297:AWG">Aruba</option>
<option value="AU:+61:AUD">Australia</option>
<option value="AT:+43:EUR">Austria</option>
<option value="AZ:+994:AZN">Azerbaijan</option>

<!--Countries Starting with B-->
<option value="BS:+1 242:BSD">Bahamas</option>
<option value="BH:+973:BHD">Bahrain</option>
<option value="BD:+880:BDT">Bangladesh</option>
<option value="BB:+1 246:BBD">Barbados</option>
<option value="BY:+375:BYR">Belarus</option>
<option value="BE:+32:EUR">Belgium</option>
<option value="BZ:+501:BZD">Belize</option>
<option value="BJ:+229:XOF">Benin</option>
<option value="BM:+1 441:BMD">Bermuda</option>
<option value="BT:+975:BTN">Bhutan</option>
<option value="BO:+591:BOB">Bolivia</option>
<option value="BA:+387:BAM">Bosnia and Herzegowina</option>
<option value="BW:+267:BWP">Botswana</option>
<!--<option value="BV:0:NOK">Bouvet Island</option>-->
<option value="BR:+55:BRL">Brazil</option>
<option value="IO:+246:GBP">British Indian Ocean Territory</option>
<option value="BN:+673:BND">Brunei Darussalam</option>
<option value="BG:+359:BGN">Bulgaria</option>
<option value="BF:+226:XOF">Burkina Faso</option>
<option value="BI:+257:BIF">Burundi</option>

<!--Countries Starting with C-->
<option value="KH:+855:KHR">Cambodia</option>
<option value="CM:+237:XAF">Cameroon</option>
<option value="CA:+1:CAD">Canada</option>
<option value="CV:+238:CVE">Cape Verde</option>
<option value="KY:+1 345:KYD">Cayman Islands</option>
<option value="CF:+236:XAF">Central African Republic</option>
<option value="TD:+235:XAF">Chad</option>
<option value="CL:+56:CLP">Chile</option>
<option value="CN:+86:CYN">China</option>
<option value="CX:+61 8 9164:AUD">Christmas Island</option>
<option value="CC:+61 8 9162:AUD">Cocos (Keeling) Islands</option>
<option value="CO:+57:COP">Colombia</option>
<option value="KM:+269:KMF">Comoros</option>
<option value="CG:+242:XAF">Congo</option>
<option value="CD:+243:CDZ">Congo, the Democratic Republic of the</option>
<option value="CK:+682:NZD">Cook Islands</option>
<option value="CR:+506:CRC">Costa Rica</option>
<option value="CI:+225:XOF">Cote d'Ivoire</option>
<option value="HR:+385:HRK">Croatia (Hrvatska)</option>
<option value="CU:+53:CUP">Cuba</option>
<option value="CY:+357:EUR">Cyprus</option>
<option value="CZ:+420:CZK">Czech Republic</option>

<!--Countries Starting with D-->
<option value="DK:+45:DKK">Denmark</option>
<option value="DJ:+253:DJF">Djibouti</option>
<option value="DM:+1 767:XCD">Dominica</option>
<option value="DO:+1 809:DOP">Dominican Republic</option>

<!--Countries Starting with E-->
<option value="EC:+593:ECS">Ecuador</option>
<option value="EG:+20:EGP">Egypt</option>
<option value="SV:+503:USD">El Salvador</option>
<option value="GQ:+240:XAF">Equatorial Guinea</option>
<option value="ER:+291:ERN">Eritrea</option>
<option value="EE:+372:EEK">Estonia</option>
<option value="ET:+251:ETB">Ethiopia</option>

<!--Countries Starting with F-->
<option value="FK:+500:FKP">Falkland Islands (Malvinas)</option>
<option value="FO:+298:DKK">Faroe Islands</option>
<option value="FJ:+679:FJD">Fiji</option>
<option value="FI:+358:EUR">Finland</option>
<option value="FR:+33:EUR">France</option>
<option value="GF:+594:EUR">French Guiana</option>
<option value="PF:+689:XPF">French Polynesia</option>
<!--<option value="TF:0:EUR">French Southern Territories</option>-->

<!--Countries Starting with G-->
<option value="GA:+241:XAF">Gabon</option>
<option value="GM:+220:GMD">Gambia</option>
<option value="GE:+995:GEL">Georgia</option>
<option value="DE:+49:EUR">Germany</option>
<option value="GH:+233:GHS">Ghana</option>
<option value="GI:+350:GIP">Gibraltar</option>
<option value="GR:+30:EUR">Greece</option>
<option value="GL:+299:DKK">Greenland</option>
<option value="GD:+1 473:XCD">Grenada</option>
<option value="GP:+590:EUR">Guadeloupe</option>
<option value="GU:+1 671:USD">Guam</option>
<option value="GT:+502:GTQ">Guatemala</option>
<option value="GN:+224:GNS">Guinea</option>
<option value="GW:+245:GWP">Guinea-Bissau</option>
<option value="GY:+592:GYD">Guyana</option>

<!--Countries Starting with H-->
<option value="HT:+509:HTG">Haiti</option>
<!--<option value="HM:0:AUD">Heard and Mc Donald Islands</option>-->
<option value="VA:+379:EUR">Holy See (Vatican City State)</option>
<option value="HN:+504:HNL">Honduras</option>
<option value="HK:+852:HKD">Hong Kong</option>
<option value="HU:+36:HUF">Hungary</option>

<!--Countries Starting with I-->
<option value="IS:+354:ISK">Iceland</option>
<option value="IN:+91:INR">India</option>
<option value="ID:+62:IDR">Indonesia</option>
<option value="IR:+98:IRR">Iran (Islamic Republic of)</option>
<option value="IQ:+964:IQD">Iraq</option>
<option value="IE:+353:EUR">Ireland</option>
<option value="IL:+972:ILS">Israel</option>
<option value="IT:+39:EUR">Italy</option>

<!--Countries Starting with J-->
<option value="JM:+1 876:JMD">Jamaica</option>
<option value="JP:+81:JPY">Japan</option>
<option value="JO:+962:JOD">Jordan</option>

<!--Countries Starting with K-->
<option value="KZ:+7:KZT">Kazakhstan</option>
<option value="KE:+254:KES">Kenya</option>
<option value="KI:+686:AUD">Kiribati</option>
<option value="KP:+850:KPW">Korea, Democratic People's Republic of</option>
<option value="KR:+82:KRW">Korea, Republic of</option>
<option value="KW:+965:KWD">Kuwait</option>
<option value="KG:+996:KGS">Kyrgyzstan</option>

<!--Countries Starting with L-->
<option value="LA:+856:LAK">Lao People's Democratic Republic</option>
<option value="LV:+371:EUR">Latvia</option>
<option value="LB:+961:LBP">Lebanon</option>
<option value="LS:+266:LSL">Lesotho</option>
<option value="LR:+231:LRD">Liberia</option>
<option value="LY:+218:LYD">Libyan Arab Jamahiriya</option>
<option value="LI:+423:CHF">Liechtenstein</option>
<option value="LT:+370:LTL">Lithuania</option>
<option value="LU:+352:EUR">Luxembourg</option>

<!--Countries Starting with M-->
<option value="MO:+853:MOP">Macau</option>
<option value="MK:+389:MKD">Macedonia, The Former Yugoslav Republic of</option>
<option value="MG:+261:MGF">Madagascar</option>
<option value="MW:+265:MWK">Malawi</option>
<option value="MY:+60:MYR">Malaysia</option>
<option value="MV:+960:MVR">Maldives</option>
<option value="ML:+223:XAF">Mali</option>
<option value="MT:+356:EUR">Malta</option>
<option value="MH:+692:USD">Marshall Islands</option>
<option value="MQ:+596:EUR">Martinique</option>
<option value="MR:+222:MRO">Mauritania</option>
<option value="MU:+230:MUR">Mauritius</option>
<option value="YT:+639:EUR">Mayotte</option>
<option value="MX:+52:MXN">Mexico</option>
<option value="FM:+691:USD">Micronesia, Federated States of</option>
<option value="MD:+373:MDL">Moldova, Republic of</option>
<option value="MC:+377:EUR">Monaco</option>
<option value="MN:+976:MNT">Mongolia</option>
<option value="ME:+382:CSD">Montenegro</option>
<option value="MS:+1 664:XCD">Montserrat</option>
<option value="MA:+212:MAD">Morocco</option>
<option value="MZ:+258:MZN">Mozambique</option>
<option value="MM:+95:MMK">Myanmar (Burma) </option>

<!--Countries Starting with N-->
<option value="NA:+264:NAD">Namibia</option>
<option value="NR:+674:AUD">Nauru</option>
<option value="NP:+977:NPR">Nepal</option>
<option value="NL:+31:EUR">Netherlands</option>
<option value="AN:+599:ANG">Netherlands Antilles</option>
<option value="NC:+687:XPF">New Caledonia</option>
<option value="NZ:+64:NZD">New Zealand</option>
<option value="NI:+505:NIO">Nicaragua</option>
<option value="NE:+227:XOF">Niger</option>
<option value="NG:+234:NGN">Nigeria</option>
<option value="NU:+683:NZD">Niue</option>
<option value="NF:+672:AUD">Norfolk Island</option>
<option value="MP:+1 670:USD">Northern Mariana Islands</option>
<option value="NO:+47:NOK">Norway</option>

<!--Countries Starting with O-->
<option value="OM:+968:OMR">Oman</option>

<!--Countries Starting with P-->
<option value="PK:+92:PKR">Pakistan</option>
<option value="PS:+970:PSE">Palestine *</option>
<option value="PW:+680:USD">Palau</option>
<option value="PA:+507:PAB">Panama</option>
<option value="PG:+675:PGK">Papua New Guinea</option>
<option value="PY:+595:PYG">Paraguay</option>
<option value="PE:+51:PEN">Peru</option>
<option value="PH:+63:PHP">Philippines</option>
<option value="PN:+64:NZD">Pitcairn</option>
<option value="PL:+48:PLN">Poland</option>
<option value="PT:+351:EUR">Portugal</option>
<option value="PR:+1 787:USD">Puerto Rico</option>

<!--Countries Starting with Q-->
<option value="QA:+974:QAR">Qatar</option>

<!--Countries Starting with R-->
<option value="RE:+262:EUR">Reunion</option>
<option value="RO:+40:RON">Romania</option>
<option value="RU:+7:RUB">Russian Federation</option>
<option value="RW:+250:RWF">Rwanda</option>

<!--Countries Starting with S-->
<option value="KN:+1 869:XCD">Saint Kitts and Nevis</option>
<option value="LC:+1 758:XCD">Saint LUCIA</option>
<option value="VC:+1 784:XCD">Saint Vincent and the Grenadines</option>
<option value="WS:+685:WST">Samoa</option>
<option value="SM:+378:EUR">San Marino</option>
<option value="ST:+239:STD">Sao Tome and Principe</option>
<option value="SA:+966:SAR">Saudi Arabia</option>
<option value="SN:+221:XOF">Senegal</option>
<option value="RS:+381:RSD">Serbia</option>
<option value="SC:+248:SCR">Seychelles</option>
<option value="SL:+232:SLL">Sierra Leone</option>
<option value="SG:+65:SGD">Singapore</option>
<option value="SK:+421:SKK">Slovakia (Slovak Republic)</option>
<option value="SI:+386:EUR">Slovenia</option>
<option value="SB:+677:SBD">Solomon Islands</option>
<option value="SO:+252:SOS">Somalia</option>
<option value="ZA:+27:ZAR">South Africa</option>
<option value="SU:+211:SDP">South Sudan</option>
<option value="GS:+500:GBP">South Georgia and the South Sandwich Islands</option>
<option value="ES:+34:EUR">Spain</option>
<option value="LK:+94:LKR">Sri Lanka</option>
<option value="SH:+290:SHP">St. Helena</option>
<option value="PM:+508:EUR">St. Pierre and Miquelon</option>
<option value="SD:+249:SDG">Sudan</option>
<option value="SR:+597:SRD">Suriname</option>
<option value="SJ:+47 79:NOK">Svalbard and Jan Mayen Islands</option>
<option value="SZ:+268:SZL">Swaziland</option>
<option value="SE:+46:SEK">Sweden</option>
<option value="CH:+41:CHF">Switzerland</option>
<option value="SY:+963:SYP">Syrian Arab Republic</option>

<!--Countries Starting with T-->
<option value="TW:+886:TWD">Taiwan, Province of China</option>
<option value="TJ:+992:TJS">Tajikistan</option>
<option value="TZ:+255:TZS">Tanzania, United Republic of</option>
<option value="TH:+66:THB">Thailand</option>
<option value="TL:+670:TPE">Timor-Leste</option>
<option value="TG:+228:XAF">Togo</option>
<option value="TK:+690:NZD">Tokelau</option>
<option value="TO:+676:TOP">Tonga</option>
<option value="TT:+1 868:TTD">Trinidad and Tobago</option>
<option value="TN:+216:TND">Tunisia</option>
<option value="TR:+90:TRY">Turkey</option>
<option value="TM:+993:TMT">Turkmenistan</option>
<option value="TC:+1 649:USD">Turks and Caicos Islands</option>
<option value="TV:+688:AUD">Tuvalu</option>

<!--Countries Starting with U-->
<option value="UG:+256:UGX">Uganda</option>
<option value="UA:+380:UAH">Ukraine</option>
<option value="AE:+971:AED">United Arab Emirates</option>
<option value="GB:+44:GBP">United Kingdom</option>
<option value="US:+1:USD">United States</option>
<!--<option value="UM:0:USD">United States Minor Outlying Islands</option>-->
<option value="UY:+598:UYU">Uruguay</option>
<option value="UZ:+998:UZS">Uzbekistan</option>

<!--Countries Starting with V-->
<option value="VU:+678:VUV">Vanuatu</option>
<option value="VE:+58:VEF">Venezuela</option>
<option value="VN:+84:VND">Viet Nam</option>
<option value="VG:+1 284:GBP">Virgin Islands (British)</option>
<option value="VI:+1 340:USD">Virgin Islands (U.S.)</option>

<!--Countries Starting with W-->
<option value="WF:+681:XPF">Wallis and Futuna Islands</option>
<!--<option value="EH:0:MAD">Western Sahara</option>-->

<!--Countries Starting with Y-->
<option value="YE:+967:YER">Yemen</option>

<!--Countries Starting with Z-->
<option value="ZM:+260:ZMW">Zambia</option>
<option value="ZW:+263:ZWD">Zimbabwe</option>