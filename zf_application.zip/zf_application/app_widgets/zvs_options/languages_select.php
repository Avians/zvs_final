<?php

    //This method builds the language code.
    $zf_model_data->zvs_buildLanguageCode();
    
?>