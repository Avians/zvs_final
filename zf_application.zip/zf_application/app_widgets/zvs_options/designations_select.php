<?php

    //This method builds the designation code.
    $zf_model_data->zvs_buildDesignationCode();
    
?>