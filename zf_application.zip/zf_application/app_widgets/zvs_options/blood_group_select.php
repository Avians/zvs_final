<?php

    //This method builds the blood group code.
    $zf_model_data->zvs_buildBloodGroupCode();
    
?>