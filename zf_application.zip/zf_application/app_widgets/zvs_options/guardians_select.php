<?php

    //This method builds the guardian code.
    $zf_model_data->zvs_buildGuardianCode();
    
?>