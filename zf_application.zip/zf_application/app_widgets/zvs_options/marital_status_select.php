<?php

    //This method builds the marital status code.
    $zf_model_data->zvs_buildMaritalStatusCode();
    
?>