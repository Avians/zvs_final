</div>
<!-- END OF THE ACTUAL FORM CONTENT-->

<!-- BEGIN FORM FOOTER (COPYRIGHT) -->
<div class="copyright">
    <div class="footer-inner">
        <?php Zf_Core_Functions::Zf_ApplicationCopyright(); ?><br><br>
        <?php Zf_Core_Functions::Zf_FrameworkTagLine(); ?>
    </div>
    <div class="clearfix"><br><br></div>
</div>
<!-- END FORM FOOTER (COPYRIGHT) -->


