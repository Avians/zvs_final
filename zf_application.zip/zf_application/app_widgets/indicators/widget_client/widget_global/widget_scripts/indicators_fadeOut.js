<script type="text/javascript" >

    $(document).ready(function() {

        $('.error-fadeout').show('fast', function(){
            
            $(this).fadeOut(20000);
            
        });
        
        $('.success-fadeout').show('fast', function(){
            
            $(this).fadeOut(20000);
            
        });

    });

</script>


