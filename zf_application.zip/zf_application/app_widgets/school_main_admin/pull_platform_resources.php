<?php

  $schoolSystemCode = $zf_externalWidgetData;
  $zf_model_data->zvss_buildPlatformResources($schoolSystemCode);
  
?>