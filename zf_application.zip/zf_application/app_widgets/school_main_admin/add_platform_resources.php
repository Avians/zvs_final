<?php

  $urlParameter = $zf_externalWidgetData;
  
  //Here we build all resources lists
  $zf_model_data->zvss_buildPlatformResources($urlParameter);
  
?>