/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function() {
    
    //Manage Classes
    NewStaffFormWizard.init();
    
    //Components Picker
    ComponentsPickers.init();
    
    
});
