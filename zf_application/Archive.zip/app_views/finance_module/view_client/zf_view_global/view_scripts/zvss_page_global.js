/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function() {
   
    //Collect School Fees
    CollectSchoolFeesFormWizard.init();
    
    //Create New Budget
    CreateNewBudgetFormWizard.init();
    
    //Allocate Finances
    AllocateFinanceFormWizard.init();
    
    //Components Picker
    ComponentsPickers.init();
    
    
});
