/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function() {
    
    SuperAdminFormWizard.init();
    PlatformAdminFormWizard.init();
    NewSchoolFormWizard.init();
    NewModuleFormWizard.init();
    EditModuleFormWizard.init();
    FormSelect.init();
    ComponentsEditors.init();
    ComponentsPickers.init();
    
});
