/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function() {
   
    //Assign Subjects to Class
    AssingSubjectsToClassFormWizard.init();
    
    //Assign Subjects to Teacher
    AssingSubjectsToTeacherFormWizard.init();
    
    //Components Picker
    ComponentsPickers.init();
    
    
});
