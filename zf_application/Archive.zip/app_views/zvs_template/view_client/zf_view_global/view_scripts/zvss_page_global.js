/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function() {
    
    //Template form
    TemplateFormWizard.init();
    
    //Components Picker
    ComponentsPickers.init();
    
    
});
