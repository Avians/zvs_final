<?php

 //The reset password form is held in this widget file.
 $zf_widgetFolder = "initialize"; $zf_widgetFile = "reset_password_form.php";
 Zf_ApplicationWidgets::zf_load_widget($zf_widgetFolder, $zf_widgetFile);
 
?>