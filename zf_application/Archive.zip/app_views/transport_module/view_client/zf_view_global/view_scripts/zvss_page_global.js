/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function() {
    
    //Configure School Transport Forms
    NewTransportZoneFormWizard.init();
    NewTransportCategoryFormWizard.init();
    NewTransportRouteFormWizard.init();
    NewTransportCostFormWizard.init();
    NewTransportVehicleFormWizard.init();
    AssingCategoriesToVehiclesFormWizard.init();
    AssingRoutesToVehiclesFormWizard.init();
    AssingVehiclesToDriverFormWizard.init();
    
});
