<?php

    //This method builds the religion code.
    $zf_model_data->zvs_buildReligionCode();
    
?>