<?php

    //This method builds the role list for a given school.
    $zf_model_data->zvs_buildRoleSelectCode($zf_externalWidgetData);
    
?>