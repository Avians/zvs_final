<?php

    //This method builds the next of kin code.
    $zf_model_data->zvs_buildNextOfKinCode();
    
?>