</div>
<!-- END CONTAINER -->

<!-- BEGIN FOOTER -->
<div class="footer">
    <div class="footer-inner">
        <?php Zf_Core_Functions::Zf_ApplicationCopyright(); ?><br>
        <?php Zf_Core_Functions::Zf_FrameworkTagLine(); ?>
    </div>
    <div class="footer-tools">
        <span class="go-top">
            <i class="fa fa-angle-up"></i>
        </span>
    </div>
</div>
<!-- END FOOTER -->
