<?php

  $identificationCode = $zf_externalWidgetData;
  
  //Here we build all school hostels dropdown
  $zf_model_data->zvss_getSchoolHostels($identificationCode);
  
?>

