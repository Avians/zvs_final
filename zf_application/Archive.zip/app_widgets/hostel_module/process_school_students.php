<?php

  $identificationCode = $zf_externalWidgetData;
  
  //Here we build all school students dropdown
  $zf_model_data->zvss_getSchoolStudents($identificationCode);
  
?>

